mapboxgl.accessToken = 'pk.eyJ1IjoicmFodWxra2FtYmxlIiwiYSI6ImNsbGRrbDFtYTBibDQzZG4xY3E0dGplbGkifQ.HASJkGcvxnpcHW9uGIjNjA';
        const map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v12', // Use a Mapbox style
            center: [73.015449, 19.073622], // Center the map around Mumbai
            zoom: 11,
        });

        // Load JSON data
        fetch('/data.json')
            .then(response => response.json())
            .then(jsonData => {
                const heatmapData = jsonData.map(item => ({
                    type: 'Feature',
                    geometry: {
                        type: 'Point',
                        coordinates: [item.lng, item.lat], // Note the order: [lng, lat]
                    },
                    properties: {
                        // You can add additional properties here
                    },
                }));

                // Add a heatmap layer
                map.addLayer({
                    id: 'heatmap-layer',
                    type: 'heatmap',
                    source: {
                        type: 'geojson',
                        data: {
                            type: 'FeatureCollection',
                            features: heatmapData,
                        },
                    },
                    paint: {
                        // Adjust heatmap color and intensity
                        'heatmap-color': [
                            'interpolate',
                            ['linear'],
                            ['heatmap-density'],
                            0, 'rgba(0, 0, 255, 0)',    // Fully transparent for lowest density
                            0.1, 'rgba(0, 0, 255, 0.15)', // Reduced opacity for low-density areas
                            0.3, 'rgba(0, 255, 0, 0.3)', // Adjust opacity for medium-density areas
                            0.6, 'rgba(255, 255, 0, 0.45)', // Adjust opacity for higher-density areas
                            1, 'rgba(255, 0, 0, 0.6)', // Adjust opacity for the highest-density areas
                        ],
                        'heatmap-intensity': [
                            'interpolate',
                            ['linear'],
                            ['zoom'],
                            0, 1,
                            9, 3,
                        ],
                    },
                });
            });